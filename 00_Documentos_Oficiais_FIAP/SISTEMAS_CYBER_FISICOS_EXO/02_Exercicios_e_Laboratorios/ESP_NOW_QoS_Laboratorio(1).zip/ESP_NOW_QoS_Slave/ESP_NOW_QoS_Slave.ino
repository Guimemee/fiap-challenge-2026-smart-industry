/*
 * ESP-NOW QoS Laboratory - SLAVE
 * Target: ESP32 + Arduino-ESP32 3.x
 *
 * Receives synthetic sensor data from MASTER and implements educational
 * application-layer behavior equivalent to:
 *   QoS 0: process every DATA received; no response.
 *   QoS 1: process every DATA received and return ACK.
 *          Retransmission can therefore produce application duplicates.
 *   QoS 2: DATA -> PUBREC; process only on PUBREL; return PUBCOMP.
 *          Completed sequence IDs are cached to suppress re-processing.
 *
 * This code uses a FreeRTOS queue so the ESP-NOW callback stays short.
 */

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>

static const uint8_t ESPNOW_CHANNEL = 1;
static const uint8_t BROADCAST_ADDR[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
static const uint16_t PROTOCOL_MAGIC = 0xEC32;
static const uint8_t PROTOCOL_VERSION = 1;

enum MsgType : uint8_t {
  MSG_DATA    = 1,
  MSG_ACK     = 2,
  MSG_PUBREC  = 3,
  MSG_PUBREL  = 4,
  MSG_PUBCOMP = 5
};

enum SensorType : uint8_t {
  SENSOR_TEMPERATURE = 1,
  SENSOR_VELOCITY    = 2,
  SENSOR_PRESSURE    = 3,
  SENSOR_ANGLE       = 4,
  SENSOR_EMG         = 5
};

struct __attribute__((packed)) Packet {
  uint16_t magic;
  uint8_t  version;
  uint8_t  type;
  uint8_t  qos;
  uint8_t  sensor;
  uint16_t flags;
  uint32_t seq;
  uint32_t sample_ms;
  float    value;
  uint32_t checksum;
};

struct SlaveStats {
  uint32_t validFrames = 0;
  uint32_t invalidFrames = 0;
  uint32_t dataFrames = 0;
  uint32_t appProcessed = 0;
  uint32_t duplicateDataArrivals = 0;
  uint32_t qos2DuplicatesSuppressed = 0;
  uint32_t responsesSent = 0;
};

QueueHandle_t rxQueue;
SlaveStats stats;

static const size_t SEEN_CACHE_SIZE = 64;
uint32_t seenData[SEEN_CACHE_SIZE] = {0};
size_t seenHead = 0;

uint32_t completedQos2[SEEN_CACHE_SIZE] = {0};
size_t completedHead = 0;

// One in-flight QoS2 transaction is enough for this point-to-point laboratory.
bool qos2Pending = false;
Packet qos2PendingPacket {};

// -----------------------------------------------------------------------------
// Utility
// -----------------------------------------------------------------------------

uint32_t fnv1a(const uint8_t* data, size_t len) {
  uint32_t hash = 2166136261UL;
  for (size_t i = 0; i < len; ++i) {
    hash ^= data[i];
    hash *= 16777619UL;
  }
  return hash;
}

void sealPacket(Packet &p) {
  p.checksum = 0;
  p.checksum = fnv1a(reinterpret_cast<const uint8_t*>(&p), sizeof(Packet));
}

bool validPacket(const Packet &p) {
  if (p.magic != PROTOCOL_MAGIC || p.version != PROTOCOL_VERSION) return false;
  Packet tmp = p;
  uint32_t received = tmp.checksum;
  tmp.checksum = 0;
  return received == fnv1a(reinterpret_cast<const uint8_t*>(&tmp), sizeof(Packet));
}

const char* sensorName(uint8_t s) {
  switch (s) {
    case SENSOR_TEMPERATURE: return "Temperatura";
    case SENSOR_VELOCITY:    return "Velocidade";
    case SENSOR_PRESSURE:    return "Pressao";
    case SENSOR_ANGLE:       return "Angulo";
    case SENSOR_EMG:         return "EMG";
    default:                 return "?";
  }
}

const char* unitName(uint8_t s) {
  switch (s) {
    case SENSOR_TEMPERATURE: return "C";
    case SENSOR_VELOCITY:    return "m/s";
    case SENSOR_PRESSURE:    return "kPa";
    case SENSOR_ANGLE:       return "graus";
    case SENSOR_EMG:         return "ADC";
    default:                 return "";
  }
}

const char* msgName(uint8_t t) {
  switch (t) {
    case MSG_DATA:    return "DATA";
    case MSG_ACK:     return "ACK";
    case MSG_PUBREC:  return "PUBREC";
    case MSG_PUBREL:  return "PUBREL";
    case MSG_PUBCOMP: return "PUBCOMP";
    default:          return "?";
  }
}

bool cacheContains(const uint32_t *cache, uint32_t seq) {
  for (size_t i = 0; i < SEEN_CACHE_SIZE; ++i) {
    if (cache[i] == seq) return true;
  }
  return false;
}

void addSeen(uint32_t seq) {
  seenData[seenHead] = seq;
  seenHead = (seenHead + 1) % SEEN_CACHE_SIZE;
}

void addCompleted(uint32_t seq) {
  completedQos2[completedHead] = seq;
  completedHead = (completedHead + 1) % SEEN_CACHE_SIZE;
}

// -----------------------------------------------------------------------------
// ESP-NOW
// -----------------------------------------------------------------------------

void sendResponse(const Packet &source, MsgType responseType) {
  Packet r {};
  r.magic = PROTOCOL_MAGIC;
  r.version = PROTOCOL_VERSION;
  r.type = responseType;
  r.qos = source.qos;
  r.sensor = source.sensor;
  r.seq = source.seq;
  r.sample_ms = source.sample_ms;
  r.value = source.value;
  sealPacket(r);

  if (esp_now_send(BROADCAST_ADDR,
                   reinterpret_cast<const uint8_t*>(&r),
                   sizeof(r)) == ESP_OK) {
    stats.responsesSent++;
    Serial.printf("[TX] %s seq=%lu\n", msgName(r.type), (unsigned long)r.seq);
  } else {
    Serial.printf("[TX ERRO] %s seq=%lu\n", msgName(r.type), (unsigned long)r.seq);
  }
}

void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *incomingData, int len) {
  if (len != sizeof(Packet) || rxQueue == nullptr) return;
  Packet p;
  memcpy(&p, incomingData, sizeof(Packet));
  // ESP-NOW receive callbacks run in the Wi-Fi task context, not in a hardware ISR.
  // Use a zero-wait queue send so the callback remains short and non-blocking.
  xQueueSend(rxQueue, &p, 0);
}

void initEspNow() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ERRO: nao foi possivel iniciar ESP-NOW.");
    while (true) delay(1000);
  }

  esp_now_register_recv_cb(onDataRecv);

  esp_now_peer_info_t peerInfo {};
  memcpy(peerInfo.peer_addr, BROADCAST_ADDR, 6);
  peerInfo.channel = ESPNOW_CHANNEL;
  peerInfo.encrypt = false;

  if (!esp_now_is_peer_exist(BROADCAST_ADDR)) {
    if (esp_now_add_peer(&peerInfo) != ESP_OK) {
      Serial.println("ERRO: nao foi possivel adicionar peer broadcast.");
      while (true) delay(1000);
    }
  }

  Serial.print("MAC SLAVE: ");
  Serial.println(WiFi.macAddress());
  Serial.printf("Canal ESP-NOW: %u\n", ESPNOW_CHANNEL);
}

// -----------------------------------------------------------------------------
// QoS application behavior
// -----------------------------------------------------------------------------

void processApplicationData(const Packet &p, bool duplicate) {
  stats.appProcessed++;

  Serial.printf("[APP] QoS=%u seq=%lu | %s = %.2f %s%s\n",
                p.qos,
                (unsigned long)p.seq,
                sensorName(p.sensor),
                p.value,
                unitName(p.sensor),
                duplicate ? " | DUPLICATA PROCESSADA" : "");
}

void handleData(const Packet &p) {
  stats.dataFrames++;

  bool duplicate = cacheContains(seenData, p.seq);
  if (duplicate) {
    stats.duplicateDataArrivals++;
  } else {
    addSeen(p.seq);
  }

  if (p.qos == 0) {
    // Best effort: anything that arrives is processed; no confirmation.
    processApplicationData(p, duplicate);
    return;
  }

  if (p.qos == 1) {
    // "At least once": process each delivery. If ACK was lost at MASTER,
    // the retry creates a duplicate application execution, intentionally
    // visible in this laboratory.
    processApplicationData(p, duplicate);
    sendResponse(p, MSG_ACK);
    return;
  }

  if (p.qos == 2) {
    // If already committed, a duplicate DATA should not re-execute the app.
    // Re-send PUBREC so MASTER can continue/recover the handshake.
    if (cacheContains(completedQos2, p.seq)) {
      stats.qos2DuplicatesSuppressed++;
      Serial.printf("[QoS2] DATA seq=%lu ja concluida; execucao suprimida.\n",
                    (unsigned long)p.seq);
      sendResponse(p, MSG_PUBREC);
      return;
    }

    // First DATA or retransmitted DATA before PUBREL.
    if (!qos2Pending || qos2PendingPacket.seq != p.seq) {
      qos2Pending = true;
      qos2PendingPacket = p;
      Serial.printf("[QoS2] DATA seq=%lu armazenada, aguardando PUBREL.\n",
                    (unsigned long)p.seq);
    } else {
      Serial.printf("[QoS2] DATA seq=%lu repetida antes de PUBREL.\n",
                    (unsigned long)p.seq);
    }

    sendResponse(p, MSG_PUBREC);
  }
}

void handlePubRel(const Packet &p) {
  if (p.qos != 2) return;

  if (cacheContains(completedQos2, p.seq)) {
    stats.qos2DuplicatesSuppressed++;
    Serial.printf("[QoS2] PUBREL duplicado seq=%lu; APP nao repetida.\n",
                  (unsigned long)p.seq);
    sendResponse(p, MSG_PUBCOMP);
    return;
  }

  if (qos2Pending && qos2PendingPacket.seq == p.seq) {
    processApplicationData(qos2PendingPacket, false);
    addCompleted(p.seq);
    qos2Pending = false;
    sendResponse(p, MSG_PUBCOMP);
  } else {
    // Defensive behavior: still return PUBCOMP only if already known.
    Serial.printf("[QoS2] PUBREL seq=%lu sem DATA pendente; ignorado.\n",
                  (unsigned long)p.seq);
  }
}

void handlePacket(const Packet &p) {
  if (!validPacket(p)) {
    stats.invalidFrames++;
    Serial.println("[RX] pacote invalido/checksum incorreto.");
    return;
  }

  stats.validFrames++;
  Serial.printf("[RX] %s qos=%u seq=%lu\n",
                msgName(p.type), p.qos, (unsigned long)p.seq);

  if (p.type == MSG_DATA) {
    handleData(p);
  } else if (p.type == MSG_PUBREL) {
    handlePubRel(p);
  }
}

void serviceRx() {
  Packet p;
  while (xQueueReceive(rxQueue, &p, 0) == pdTRUE) {
    handlePacket(p);
  }
}

// -----------------------------------------------------------------------------
// Serial
// -----------------------------------------------------------------------------

void printStats() {
  Serial.println("\n--- ESTATISTICAS SLAVE ---");
  Serial.printf("Frames validos............: %lu\n", (unsigned long)stats.validFrames);
  Serial.printf("Frames invalidos..........: %lu\n", (unsigned long)stats.invalidFrames);
  Serial.printf("DATA recebidos............: %lu\n", (unsigned long)stats.dataFrames);
  Serial.printf("Execucoes da aplicacao....: %lu\n", (unsigned long)stats.appProcessed);
  Serial.printf("DATA duplicados observados: %lu\n", (unsigned long)stats.duplicateDataArrivals);
  Serial.printf("Duplicatas QoS2 suprimidas: %lu\n", (unsigned long)stats.qos2DuplicatesSuppressed);
  Serial.printf("Respostas enviadas........: %lu\n", (unsigned long)stats.responsesSent);
}

void serviceSerial() {
  static String line;
  while (Serial.available()) {
    char c = char(Serial.read());
    if (c == '\n' || c == '\r') {
      line.trim();
      line.toLowerCase();
      if (line == "stats") printStats();
      else if (line == "resetstats") {
        stats = SlaveStats();
        memset(seenData, 0, sizeof(seenData));
        memset(completedQos2, 0, sizeof(completedQos2));
        seenHead = completedHead = 0;
        qos2Pending = false;
        Serial.println("Estatisticas/caches zerados.");
      } else if (line == "help") {
        Serial.println("Comandos SLAVE: stats | resetstats | help");
      }
      line = "";
    } else {
      line += c;
    }
  }
}

// -----------------------------------------------------------------------------
// Arduino lifecycle
// -----------------------------------------------------------------------------

void setup() {
  Serial.begin(115200);
  delay(500);

  rxQueue = xQueueCreate(12, sizeof(Packet));
  if (rxQueue == nullptr) {
    Serial.println("ERRO: nao foi possivel criar fila FreeRTOS.");
    while (true) delay(1000);
  }

  initEspNow();

  Serial.println(R"TXT(
ESP-NOW QoS LAB - SLAVE pronto.
Abra este monitor em 115200 baud.
Comandos: stats | resetstats | help
Aguarde os frames do MASTER.
)TXT");
}

void loop() {
  serviceSerial();
  serviceRx();
  delay(1);
}
