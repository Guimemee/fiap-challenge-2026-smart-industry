/*
 * ESP-NOW QoS Laboratory - MASTER
 * Target: ESP32 + Arduino-ESP32 3.x
 *
 * Educational application-layer implementation inspired by QoS 0/1/2:
 *   QoS 0: DATA only (best effort)
 *   QoS 1: DATA -> ACK, with timeout/retry ("at least once")
 *   QoS 2: DATA -> PUBREC -> PUBREL -> PUBCOMP ("exactly once" at application)
 *
 * Failure injection is controlled from the Serial Monitor:
 *   - simulated loss of MASTER->SLAVE frames
 *   - simulated loss of SLAVE->MASTER responses
 *   - deliberate duplicate DATA frames
 *   - random artificial jitter
 *
 * IMPORTANT:
 * This is an educational protocol built on top of ESP-NOW. It is NOT MQTT
 * and does not claim to modify the internal QoS behavior of ESP-NOW.
 */

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <math.h>

static const uint8_t ESPNOW_CHANNEL = 1;
static const uint8_t BROADCAST_ADDR[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
static const uint16_t PROTOCOL_MAGIC = 0xEC32;
static const uint8_t PROTOCOL_VERSION = 1;

enum MsgType : uint8_t {
  MSG_DATA    = 1,
  MSG_ACK     = 2,
  MSG_PUBREC  = 3,
  MSG_PUBREL  = 4,
  MSG_PUBCOMP = 5
};

enum SensorType : uint8_t {
  SENSOR_TEMPERATURE = 1,
  SENSOR_VELOCITY    = 2,
  SENSOR_PRESSURE    = 3,
  SENSOR_ANGLE       = 4,
  SENSOR_EMG         = 5
};

struct __attribute__((packed)) Packet {
  uint16_t magic;
  uint8_t  version;
  uint8_t  type;
  uint8_t  qos;
  uint8_t  sensor;
  uint16_t flags;
  uint32_t seq;
  uint32_t sample_ms;
  float    value;
  uint32_t checksum;
};

struct Stats {
  uint32_t generated = 0;
  uint32_t txAttempts = 0;
  uint32_t simulatedTxDrops = 0;
  uint32_t simulatedRxDrops = 0;
  uint32_t deliberateDuplicates = 0;
  uint32_t retries = 0;
  uint32_t completed = 0;
  uint32_t failed = 0;
  uint64_t rttAccumUs = 0;
};

struct FailureConfig {
  uint8_t txLossPct = 0;     // MASTER -> SLAVE frame loss
  uint8_t ackLossPct = 0;    // ignore SLAVE -> MASTER response
  uint8_t duplicatePct = 0;  // duplicate DATA
  uint16_t jitterMaxMs = 0;  // artificial delay before physical send
};

enum TxState : uint8_t {
  TX_IDLE = 0,
  TX_WAIT_ACK,
  TX_WAIT_PUBREC,
  TX_WAIT_PUBCOMP
};

QueueHandle_t rxQueue;

SensorType selectedSensor = SENSOR_TEMPERATURE;
uint8_t selectedQoS = 0;
FailureConfig failure;
Stats stats;

bool running = false;
uint32_t requestedSamples = 0; // 0 = continuous
uint32_t samplesStartedInRun = 0;
uint32_t sampleIntervalMs = 500;
uint32_t protocolTimeoutMs = 350;
uint8_t maxRetries = 4;

uint32_t sequenceCounter = 1;
uint32_t nextSampleAt = 0;

Packet currentPacket {};
TxState txState = TX_IDLE;
uint8_t currentRetries = 0;
uint32_t stateDeadline = 0;
uint64_t transactionStartUs = 0;

// -----------------------------------------------------------------------------
// Utility
// -----------------------------------------------------------------------------

uint32_t fnv1a(const uint8_t* data, size_t len) {
  uint32_t hash = 2166136261UL;
  for (size_t i = 0; i < len; ++i) {
    hash ^= data[i];
    hash *= 16777619UL;
  }
  return hash;
}

void sealPacket(Packet &p) {
  p.checksum = 0;
  p.checksum = fnv1a(reinterpret_cast<const uint8_t*>(&p), sizeof(Packet));
}

bool validPacket(const Packet &p) {
  if (p.magic != PROTOCOL_MAGIC || p.version != PROTOCOL_VERSION) return false;
  Packet tmp = p;
  uint32_t received = tmp.checksum;
  tmp.checksum = 0;
  return received == fnv1a(reinterpret_cast<const uint8_t*>(&tmp), sizeof(Packet));
}

const char* sensorName(uint8_t s) {
  switch (s) {
    case SENSOR_TEMPERATURE: return "Temperatura";
    case SENSOR_VELOCITY:    return "Velocidade";
    case SENSOR_PRESSURE:    return "Pressao";
    case SENSOR_ANGLE:       return "Angulo";
    case SENSOR_EMG:         return "EMG";
    default:                 return "?";
  }
}

const char* unitName(uint8_t s) {
  switch (s) {
    case SENSOR_TEMPERATURE: return "C";
    case SENSOR_VELOCITY:    return "m/s";
    case SENSOR_PRESSURE:    return "kPa";
    case SENSOR_ANGLE:       return "graus";
    case SENSOR_EMG:         return "ADC";
    default:                 return "";
  }
}

const char* msgName(uint8_t t) {
  switch (t) {
    case MSG_DATA:    return "DATA";
    case MSG_ACK:     return "ACK";
    case MSG_PUBREC:  return "PUBREC";
    case MSG_PUBREL:  return "PUBREL";
    case MSG_PUBCOMP: return "PUBCOMP";
    default:          return "?";
  }
}

// -----------------------------------------------------------------------------
// Digital sensor simulation
// -----------------------------------------------------------------------------

float randomFloat(float minV, float maxV) {
  return minV + (maxV - minV) * (float(random(0, 10001)) / 10000.0f);
}

float simulateSensor(SensorType sensor) {
  const float t = millis() / 1000.0f;

  switch (sensor) {
    case SENSOR_TEMPERATURE:
      // Slow environmental variation + digital noise
      return 25.0f + 4.0f * sinf(t * 0.45f) + randomFloat(-0.25f, 0.25f);

    case SENSOR_VELOCITY: {
      // Positive varying speed, roughly 0..12 m/s
      float v = 5.5f + 4.5f * sinf(t * 0.8f) + randomFloat(-0.20f, 0.20f);
      return max(0.0f, v);
    }

    case SENSOR_PRESSURE:
      // Atmospheric/process-like pressure
      return 101.3f + 3.0f * sinf(t * 0.25f) + randomFloat(-0.15f, 0.15f);

    case SENSOR_ANGLE: {
      // Triangle wave exactly constrained to 0..180 degrees
      const uint32_t periodMs = 6000;
      uint32_t phase = millis() % periodMs;
      if (phase < periodMs / 2) {
        return 180.0f * (float(phase) / float(periodMs / 2));
      } else {
        return 180.0f * (1.0f - float(phase - periodMs / 2) / float(periodMs / 2));
      }
    }

    case SENSOR_EMG: {
      // ADC-like envelope: baseline noise plus periodic "muscle contraction" bursts.
      // Output is a synthetic 12-bit ADC value (0..4095).
      float baseline = 180.0f + randomFloat(-60.0f, 60.0f);
      bool burst = (millis() % 5000UL) > 3200UL && (millis() % 5000UL) < 4100UL;
      float signal = baseline;
      if (burst) {
        signal += 1700.0f
               + 800.0f * fabsf(sinf(t * 18.0f))
               + randomFloat(-250.0f, 250.0f);
      }
      return constrain(signal, 0.0f, 4095.0f);
    }
  }
  return 0.0f;
}

// -----------------------------------------------------------------------------
// ESP-NOW
// -----------------------------------------------------------------------------

bool chance(uint8_t pct) {
  if (pct == 0) return false;
  if (pct >= 100) return true;
  return random(0, 100) < pct;
}

bool physicalSend(const Packet &packet, bool applyFailureInjection = true) {
  stats.txAttempts++;

  if (applyFailureInjection && chance(failure.txLossPct)) {
    stats.simulatedTxDrops++;
    Serial.printf("[FALHA] TX descartado artificialmente: %s seq=%lu\n",
                  msgName(packet.type), (unsigned long)packet.seq);
    return false; // intentionally not put on the air
  }

  if (applyFailureInjection && failure.jitterMaxMs > 0) {
    // Educational fault injector. A production design should normally schedule
    // this non-blockingly rather than calling delay().
    delay(random(0, failure.jitterMaxMs + 1));
  }

  esp_err_t err = esp_now_send(BROADCAST_ADDR,
                               reinterpret_cast<const uint8_t*>(&packet),
                               sizeof(packet));
  if (err != ESP_OK) {
    Serial.printf("[ERRO] esp_now_send() = %d\n", int(err));
    return false;
  }

  if (applyFailureInjection && packet.type == MSG_DATA && chance(failure.duplicatePct)) {
    stats.deliberateDuplicates++;
    delay(2);
    esp_now_send(BROADCAST_ADDR,
                 reinterpret_cast<const uint8_t*>(&packet),
                 sizeof(packet));
    Serial.printf("[FALHA] Duplicata deliberada: DATA seq=%lu\n",
                  (unsigned long)packet.seq);
  }
  return true;
}

void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *incomingData, int len) {
  if (len != sizeof(Packet) || rxQueue == nullptr) return;
  Packet p;
  memcpy(&p, incomingData, sizeof(Packet));
  // ESP-NOW receive callbacks run in the Wi-Fi task context, not in a hardware ISR.
  // Use a zero-wait queue send so the callback remains short and non-blocking.
  xQueueSend(rxQueue, &p, 0);
}

void initEspNow() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ERRO: nao foi possivel iniciar ESP-NOW.");
    while (true) delay(1000);
  }

  esp_now_register_recv_cb(onDataRecv);

  esp_now_peer_info_t peerInfo {};
  memcpy(peerInfo.peer_addr, BROADCAST_ADDR, 6);
  peerInfo.channel = ESPNOW_CHANNEL;
  peerInfo.encrypt = false;

  if (!esp_now_is_peer_exist(BROADCAST_ADDR)) {
    if (esp_now_add_peer(&peerInfo) != ESP_OK) {
      Serial.println("ERRO: nao foi possivel adicionar peer broadcast.");
      while (true) delay(1000);
    }
  }

  Serial.print("MAC MASTER: ");
  Serial.println(WiFi.macAddress());
  Serial.printf("Canal ESP-NOW: %u\n", ESPNOW_CHANNEL);
}

// -----------------------------------------------------------------------------
// Application-layer QoS state machine
// -----------------------------------------------------------------------------

void makeDataPacket() {
  memset(&currentPacket, 0, sizeof(currentPacket));
  currentPacket.magic = PROTOCOL_MAGIC;
  currentPacket.version = PROTOCOL_VERSION;
  currentPacket.type = MSG_DATA;
  currentPacket.qos = selectedQoS;
  currentPacket.sensor = selectedSensor;
  currentPacket.seq = sequenceCounter++;
  currentPacket.sample_ms = millis();
  currentPacket.value = simulateSensor(selectedSensor);
  sealPacket(currentPacket);
}

void completeTransaction(bool success) {
  if (success) {
    stats.completed++;
    uint64_t elapsed = micros() - transactionStartUs;
    stats.rttAccumUs += elapsed;
    Serial.printf("[OK] seq=%lu concluida em %.2f ms\n",
                  (unsigned long)currentPacket.seq, elapsed / 1000.0);
  } else {
    stats.failed++;
    Serial.printf("[FALHA FINAL] seq=%lu excedeu %u retries\n",
                  (unsigned long)currentPacket.seq, maxRetries);
  }

  txState = TX_IDLE;
  currentRetries = 0;
  nextSampleAt = millis() + sampleIntervalMs;

  if (requestedSamples != 0 && samplesStartedInRun >= requestedSamples) {
    running = false;
    Serial.println("\n=== LOTE FINALIZADO ===");
  }
}

void sendDataAndWait() {
  physicalSend(currentPacket, true);

  if (selectedQoS == 1) {
    txState = TX_WAIT_ACK;
  } else {
    txState = TX_WAIT_PUBREC;
  }
  stateDeadline = millis() + protocolTimeoutMs;
}

void sendPubRelAndWait() {
  Packet p = currentPacket;
  p.type = MSG_PUBREL;
  sealPacket(p);
  physicalSend(p, true);
  txState = TX_WAIT_PUBCOMP;
  stateDeadline = millis() + protocolTimeoutMs;
}

void startOneSample() {
  stats.generated++;
  samplesStartedInRun++;
  makeDataPacket();
  transactionStartUs = micros();
  currentRetries = 0;

  Serial.printf("\n[AMOSTRA] seq=%lu | %s=%.2f %s | QoS=%u\n",
                (unsigned long)currentPacket.seq,
                sensorName(currentPacket.sensor),
                currentPacket.value,
                unitName(currentPacket.sensor),
                currentPacket.qos);

  if (selectedQoS == 0) {
    physicalSend(currentPacket, true);
    // QoS 0 cannot know whether the peer actually received the frame.
    stats.completed++;
    uint64_t elapsed = micros() - transactionStartUs;
    stats.rttAccumUs += elapsed;
    txState = TX_IDLE;
    nextSampleAt = millis() + sampleIntervalMs;

    if (requestedSamples != 0 && samplesStartedInRun >= requestedSamples) {
      running = false;
      Serial.println("\n=== LOTE FINALIZADO (QoS 0, sem confirmacao) ===");
    }
  } else {
    sendDataAndWait();
  }
}

void retryCurrentStage() {
  if (currentRetries >= maxRetries) {
    completeTransaction(false);
    return;
  }

  currentRetries++;
  stats.retries++;
  Serial.printf("[RETRY] seq=%lu tentativa adicional %u/%u no estado %u\n",
                (unsigned long)currentPacket.seq,
                currentRetries, maxRetries, txState);

  if (txState == TX_WAIT_ACK || txState == TX_WAIT_PUBREC) {
    sendDataAndWait();
  } else if (txState == TX_WAIT_PUBCOMP) {
    sendPubRelAndWait();
  }
}

void handleResponse(const Packet &p) {
  if (!validPacket(p)) {
    Serial.println("[RX] pacote invalido/checksum incorreto.");
    return;
  }

  if (p.seq != currentPacket.seq || txState == TX_IDLE) return;

  if (chance(failure.ackLossPct)) {
    stats.simulatedRxDrops++;
    Serial.printf("[FALHA] Resposta %s seq=%lu ignorada artificialmente.\n",
                  msgName(p.type), (unsigned long)p.seq);
    return;
  }

  Serial.printf("[RX] %s seq=%lu\n", msgName(p.type), (unsigned long)p.seq);

  if (selectedQoS == 1 && txState == TX_WAIT_ACK && p.type == MSG_ACK) {
    completeTransaction(true);
    return;
  }

  if (selectedQoS == 2 && txState == TX_WAIT_PUBREC && p.type == MSG_PUBREC) {
    sendPubRelAndWait();
    return;
  }

  if (selectedQoS == 2 && txState == TX_WAIT_PUBCOMP && p.type == MSG_PUBCOMP) {
    completeTransaction(true);
    return;
  }
}

void serviceProtocol() {
  Packet p;
  while (xQueueReceive(rxQueue, &p, 0) == pdTRUE) {
    handleResponse(p);
  }

  if (txState != TX_IDLE && (int32_t)(millis() - stateDeadline) >= 0) {
    Serial.printf("[TIMEOUT] seq=%lu estado=%u\n",
                  (unsigned long)currentPacket.seq, txState);
    retryCurrentStage();
  }

  if (running && txState == TX_IDLE && (int32_t)(millis() - nextSampleAt) >= 0) {
    startOneSample();
  }
}

// -----------------------------------------------------------------------------
// Serial UI
// -----------------------------------------------------------------------------

void printHelp() {
  Serial.println(R"MENU(
================ ESP-NOW QoS LAB - MASTER ================
SENSORES:
  temp               -> Temperatura simulada [C]
  vel                -> Velocidade simulada [m/s]
  press              -> Pressao simulada [kPa]
  ang                -> Angulo triangular 0..180 [graus]
  emg                -> EMG sintetico [ADC 0..4095]

QOS:
  q0                 -> best effort: DATA
  q1                 -> DATA/ACK + timeout/retry
  q2                 -> DATA/PUBREC/PUBREL/PUBCOMP

EXECUCAO:
  start N            -> envia N amostras (ex.: start 100)
  start 0            -> modo continuo
  stop               -> interrompe depois do estado atual
  rate MS            -> intervalo entre amostras
  timeout MS         -> timeout do protocolo
  retry N            -> maximo de retries

INJECAO DE FALHAS:
  loss PCT           -> perda MASTER->SLAVE, 0..100 %
  ackloss PCT        -> ignora respostas SLAVE->MASTER
  dup PCT            -> duplica DATA deliberadamente
  jitter MS          -> atraso aleatorio 0..MS antes de TX
  clean              -> zera todas as falhas

RELATORIOS:
  cfg                -> configuracao atual
  stats              -> estatisticas
  resetstats         -> zera estatisticas
  help               -> mostra este menu
===========================================================
)MENU");
}

void printConfig() {
  Serial.println("\n--- CONFIGURACAO ---");
  Serial.printf("Sensor........: %s\n", sensorName(selectedSensor));
  Serial.printf("QoS...........: %u\n", selectedQoS);
  Serial.printf("Intervalo.....: %lu ms\n", (unsigned long)sampleIntervalMs);
  Serial.printf("Timeout.......: %lu ms\n", (unsigned long)protocolTimeoutMs);
  Serial.printf("Retries max...: %u\n", maxRetries);
  Serial.printf("TX loss.......: %u %%\n", failure.txLossPct);
  Serial.printf("ACK loss......: %u %%\n", failure.ackLossPct);
  Serial.printf("Duplicacao....: %u %%\n", failure.duplicatePct);
  Serial.printf("Jitter........: 0..%u ms\n", failure.jitterMaxMs);
  Serial.printf("Executando....: %s\n", running ? "SIM" : "NAO");
}

void printStats() {
  Serial.println("\n--- ESTATISTICAS MASTER ---");
  Serial.printf("Amostras geradas........: %lu\n", (unsigned long)stats.generated);
  Serial.printf("Tentativas de TX........: %lu\n", (unsigned long)stats.txAttempts);
  Serial.printf("TX descartados simulados: %lu\n", (unsigned long)stats.simulatedTxDrops);
  Serial.printf("Respostas ignoradas.....: %lu\n", (unsigned long)stats.simulatedRxDrops);
  Serial.printf("Duplicatas deliberadas..: %lu\n", (unsigned long)stats.deliberateDuplicates);
  Serial.printf("Retries..................: %lu\n", (unsigned long)stats.retries);
  Serial.printf("Transacoes concluidas...: %lu\n", (unsigned long)stats.completed);
  Serial.printf("Transacoes falhas.......: %lu\n", (unsigned long)stats.failed);
  if (stats.completed > 0) {
    Serial.printf("Tempo medio/transacao....: %.2f ms\n",
                  (stats.rttAccumUs / double(stats.completed)) / 1000.0);
  }
  Serial.println("OBS.: no QoS 0, 'concluida' significa apenas 'enviada sem confirmacao'.");
}

String nextToken(String &line) {
  line.trim();
  int p = line.indexOf(' ');
  if (p < 0) {
    String t = line;
    line = "";
    return t;
  }
  String t = line.substring(0, p);
  line = line.substring(p + 1);
  line.trim();
  return t;
}

void processCommand(String line) {
  line.trim();
  line.toLowerCase();
  if (!line.length()) return;

  String args = line;
  String cmd = nextToken(args);

  if (cmd == "temp") selectedSensor = SENSOR_TEMPERATURE;
  else if (cmd == "vel") selectedSensor = SENSOR_VELOCITY;
  else if (cmd == "press") selectedSensor = SENSOR_PRESSURE;
  else if (cmd == "ang") selectedSensor = SENSOR_ANGLE;
  else if (cmd == "emg") selectedSensor = SENSOR_EMG;

  else if (cmd == "q0") selectedQoS = 0;
  else if (cmd == "q1") selectedQoS = 1;
  else if (cmd == "q2") selectedQoS = 2;

  else if (cmd == "start") {
    requestedSamples = args.toInt();
    samplesStartedInRun = 0;
    running = true;
    nextSampleAt = millis();
    Serial.printf("Execucao iniciada: %s\n",
                  requestedSamples == 0 ? "continua" : String(requestedSamples).c_str());
  }
  else if (cmd == "stop") {
    running = false;
    Serial.println("Solicitacao de parada registrada.");
  }
  else if (cmd == "rate") {
    sampleIntervalMs = max(10UL, (uint32_t)args.toInt());
  }
  else if (cmd == "timeout") {
    protocolTimeoutMs = max(20UL, (uint32_t)args.toInt());
  }
  else if (cmd == "retry") {
    maxRetries = constrain(args.toInt(), 0, 20);
  }
  else if (cmd == "loss") {
    failure.txLossPct = constrain(args.toInt(), 0, 100);
  }
  else if (cmd == "ackloss") {
    failure.ackLossPct = constrain(args.toInt(), 0, 100);
  }
  else if (cmd == "dup") {
    failure.duplicatePct = constrain(args.toInt(), 0, 100);
  }
  else if (cmd == "jitter") {
    failure.jitterMaxMs = constrain(args.toInt(), 0, 5000);
  }
  else if (cmd == "clean") {
    failure = FailureConfig();
    Serial.println("Injecao de falhas zerada.");
  }
  else if (cmd == "cfg") printConfig();
  else if (cmd == "stats") printStats();
  else if (cmd == "resetstats") {
    stats = Stats();
    Serial.println("Estatisticas zeradas.");
  }
  else if (cmd == "help" || cmd == "menu") printHelp();
  else {
    Serial.println("Comando desconhecido. Digite 'help'.");
    return;
  }

  if (cmd == "temp" || cmd == "vel" || cmd == "press" ||
      cmd == "ang" || cmd == "emg" ||
      cmd == "q0" || cmd == "q1" || cmd == "q2") {
    printConfig();
  }
}

void serviceSerial() {
  static String line;
  while (Serial.available()) {
    char c = char(Serial.read());
    if (c == '\n' || c == '\r') {
      if (line.length()) {
        processCommand(line);
        line = "";
      }
    } else {
      line += c;
      if (line.length() > 120) line = "";
    }
  }
}

// -----------------------------------------------------------------------------
// Arduino lifecycle
// -----------------------------------------------------------------------------

void setup() {
  Serial.begin(115200);
  delay(500);
  randomSeed(esp_random());

  rxQueue = xQueueCreate(12, sizeof(Packet));
  if (rxQueue == nullptr) {
    Serial.println("ERRO: nao foi possivel criar fila FreeRTOS.");
    while (true) delay(1000);
  }

  initEspNow();
  printHelp();
  printConfig();
}

void loop() {
  serviceSerial();
  serviceProtocol();
  delay(1);
}
