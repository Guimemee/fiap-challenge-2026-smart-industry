const uint8_t PIN_OMBRO    = 36;
const uint8_t PIN_COTOVELO = 39;

const unsigned long PERIODO_AMOSTRAGEM_MS = 20;

unsigned long ultimoInstante = 0;

const int NUM_AMOSTRAS_ADC = 8;

bool filtroSuavizacaoLigado = false;
uint8_t nivelSuavizacao = 1;
bool debounceLigado = false;
bool filtroAltasFrequenciasLigado = false;

float iirOmbro = 0.0;
float iirCotovelo = 0.0;
bool iirInicializado = false;

const float DEADBAND_GRAUS = 1.2;

float debounceOmbro = 0.0;
float debounceCotovelo = 0.0;
bool debounceInicializado = false;

const int TAMANHO_FIR = 5;

float bufferOmbro[TAMANHO_FIR];
float bufferCotovelo[TAMANHO_FIR];

int indiceFIR = 0;
bool firInicializado = false;

String comandoSerial = "";

uint16_t lerADC(uint8_t pino)
{
    uint32_t soma = 0;

    for (int i = 0; i < NUM_AMOSTRAS_ADC; i++)
    {
        soma += analogRead(pino);
    }

    return soma / NUM_AMOSTRAS_ADC;
}

float adcParaAngulo(uint16_t adc)
{
    return ((float)adc / 4095.0) * 180.0;
}

void inicializarFIR(
    float ombro,
    float cotovelo
)
{
    for (int i = 0; i < TAMANHO_FIR; i++)
    {
        bufferOmbro[i] = ombro;
        bufferCotovelo[i] = cotovelo;
    }

    indiceFIR = 0;

    firInicializado = true;
}

void aplicarFIR(
    float entradaOmbro,
    float entradaCotovelo,
    float &saidaOmbro,
    float &saidaCotovelo
)
{
    if (!firInicializado)
    {
        inicializarFIR(
            entradaOmbro,
            entradaCotovelo
        );
    }

    bufferOmbro[indiceFIR] =
        entradaOmbro;

    bufferCotovelo[indiceFIR] =
        entradaCotovelo;

    indiceFIR++;

    if (indiceFIR >= TAMANHO_FIR)
    {
        indiceFIR = 0;
    }

    float somaOmbro = 0.0;
    float somaCotovelo = 0.0;

    for (int i = 0; i < TAMANHO_FIR; i++)
    {
        somaOmbro +=
            bufferOmbro[i];

        somaCotovelo +=
            bufferCotovelo[i];
    }

    saidaOmbro =
        somaOmbro / TAMANHO_FIR;

    saidaCotovelo =
        somaCotovelo / TAMANHO_FIR;
}

void aplicarDebounce(
    float entradaOmbro,
    float entradaCotovelo,
    float &saidaOmbro,
    float &saidaCotovelo
)
{
    if (!debounceInicializado)
    {
        debounceOmbro =
            entradaOmbro;

        debounceCotovelo =
            entradaCotovelo;

        debounceInicializado =
            true;
    }

    if (
        fabs(
            entradaOmbro -
            debounceOmbro
        )
        >= DEADBAND_GRAUS
    )
    {
        debounceOmbro =
            entradaOmbro;
    }

    if (
        fabs(
            entradaCotovelo -
            debounceCotovelo
        )
        >= DEADBAND_GRAUS
    )
    {
        debounceCotovelo =
            entradaCotovelo;
    }

    saidaOmbro =
        debounceOmbro;

    saidaCotovelo =
        debounceCotovelo;
}

float obterAlpha(uint8_t nivel)
{
    switch (nivel)
    {
        case 1:
            return 0.65;

        case 2:
            return 0.45;

        case 3:
            return 0.25;

        case 4:
            return 0.12;

        case 5:
            return 0.06;

        default:
            return 0.65;
    }
}

void aplicarIIR(
    float entradaOmbro,
    float entradaCotovelo,
    float &saidaOmbro,
    float &saidaCotovelo
)
{
    if (!iirInicializado)
    {
        iirOmbro =
            entradaOmbro;

        iirCotovelo =
            entradaCotovelo;

        iirInicializado =
            true;
    }

    float alpha =
        obterAlpha(
            nivelSuavizacao
        );

    iirOmbro +=
        alpha *
        (
            entradaOmbro -
            iirOmbro
        );

    iirCotovelo +=
        alpha *
        (
            entradaCotovelo -
            iirCotovelo
        );

    saidaOmbro =
        iirOmbro;

    saidaCotovelo =
        iirCotovelo;
}

void resetarEstadosFiltros()
{
    iirInicializado = false;
    debounceInicializado = false;
    firInicializado = false;
}

int lerParametro(
    String comando,
    String nome
)
{
    String chave =
        nome + "=";

    int inicio =
        comando.indexOf(chave);

    if (inicio < 0)
    {
        return -1;
    }

    inicio +=
        chave.length();

    int fim =
        comando.indexOf(
            ',',
            inicio
        );

    if (fim < 0)
    {
        fim =
            comando.length();
    }

    String valor =
        comando.substring(
            inicio,
            fim
        );

    return valor.toInt();
}

void processarComando(
    String comando
)
{
    comando.trim();

    if (!comando.startsWith("CFG,"))
    {
        return;
    }

    int smooth =
        lerParametro(
            comando,
            "SMOOTH"
        );

    int level =
        lerParametro(
            comando,
            "LEVEL"
        );

    int debounce =
        lerParametro(
            comando,
            "DEBOUNCE"
        );

    int hff =
        lerParametro(
            comando,
            "HFF"
        );

    if (
        smooth < 0 ||
        level < 1 ||
        level > 5 ||
        debounce < 0 ||
        hff < 0
    )
    {
        Serial.println(
            "ERR,CFG"
        );

        return;
    }

    filtroSuavizacaoLigado =
        smooth == 1;

    nivelSuavizacao =
        level;

    debounceLigado =
        debounce == 1;

    filtroAltasFrequenciasLigado =
        hff == 1;

    resetarEstadosFiltros();

    Serial.print(
        "ACK,CFG,SMOOTH="
    );

    Serial.print(
        filtroSuavizacaoLigado ? 1 : 0
    );

    Serial.print(
        ",LEVEL="
    );

    Serial.print(
        nivelSuavizacao
    );

    Serial.print(
        ",DEBOUNCE="
    );

    Serial.print(
        debounceLigado ? 1 : 0
    );

    Serial.print(
        ",HFF="
    );

    Serial.println(
        filtroAltasFrequenciasLigado ? 1 : 0
    );
}

void verificarSerial()
{
    while (Serial.available())
    {
        char c =
            Serial.read();

        if (c == '\n')
        {
            processarComando(
                comandoSerial
            );

            comandoSerial = "";
        }
        else if (c != '\r')
        {
            comandoSerial += c;

            if (
                comandoSerial.length()
                > 150
            )
            {
                comandoSerial = "";
            }
        }
    }
}

void setup()
{
    Serial.begin(
        115200
    );

    analogReadResolution(
        12
    );

    pinMode(
        PIN_OMBRO,
        INPUT
    );

    pinMode(
        PIN_COTOVELO,
        INPUT
    );

    delay(500);
}

void loop()
{
    verificarSerial();

    unsigned long agora =
        millis();

    if (
        agora -
        ultimoInstante
        <
        PERIODO_AMOSTRAGEM_MS
    )
    {
        return;
    }

    ultimoInstante =
        agora;

    uint16_t adcOmbro =
        lerADC(
            PIN_OMBRO
        );

    uint16_t adcCotovelo =
        lerADC(
            PIN_COTOVELO
        );

    float ombro =
        adcParaAngulo(
            adcOmbro
        );

    float cotovelo =
        adcParaAngulo(
            adcCotovelo
        );

    if (
        filtroAltasFrequenciasLigado
    )
    {
        float novoOmbro;
        float novoCotovelo;

        aplicarFIR(
            ombro,
            cotovelo,
            novoOmbro,
            novoCotovelo
        );

        ombro =
            novoOmbro;

        cotovelo =
            novoCotovelo;
    }

    if (
        debounceLigado
    )
    {
        float novoOmbro;
        float novoCotovelo;

        aplicarDebounce(
            ombro,
            cotovelo,
            novoOmbro,
            novoCotovelo
        );

        ombro =
            novoOmbro;

        cotovelo =
            novoCotovelo;
    }

    if (
        filtroSuavizacaoLigado
    )
    {
        float novoOmbro;
        float novoCotovelo;

        aplicarIIR(
            ombro,
            cotovelo,
            novoOmbro,
            novoCotovelo
        );

        ombro =
            novoOmbro;

        cotovelo =
            novoCotovelo;
    }

    Serial.print(
        "DATA,"
    );

    Serial.print(
        ombro,
        2
    );

    Serial.print(
        ","
    );

    Serial.println(
        cotovelo,
        2
    );
}