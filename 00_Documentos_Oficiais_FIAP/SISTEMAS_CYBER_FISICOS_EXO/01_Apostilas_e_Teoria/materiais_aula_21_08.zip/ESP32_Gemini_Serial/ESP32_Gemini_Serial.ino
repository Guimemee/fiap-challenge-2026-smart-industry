#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

/* REDE  */
#define WIFI_SSID       "COLOQUE_O_NOME_DA_SUA_REDE"
#define WIFI_PASSWORD   "COLOQUE_A_SENHA_DA_SUA_REDE"

/* ============ BLOCO 2 - API ============ */
#define GEMINI_API_KEY  "COLOQUE_SUA_CHAVE_AQUI"
#define GEMINI_MODEL    "gemini-3.5-flash-lite"

/* ============ BLOCO 3 - GERACAO ============ */
#define MAX_TOKENS      200
#define TEMPERATURE     0.7

/* ============ BLOCO 4 - PERSONALIDADE ============ */
#define SYSTEM_PROMPT "Voce e um assistente embarcado rodando em um ESP32. \
Responda sempre em portugues do Brasil, de forma curta e direta."

/* ============ BLOCO 5 - DEPURACAO ============ */
#define DEBUG_JSON_BRUTO       false
#define DEBUG_FINISH_REASON    false
#define DEBUG_CONTAGEM_TOKENS  false

/* ============ BLOCO 6 - MODO AUTOMATICO ============ */
#define MODO_AUTOMATICO    false
#define INTERVALO_AUTO_MS  30000
#define PROMPT_AUTOMATICO  "Diga uma curiosidade curta sobre sistemas embarcados."

/* ============ BLOCO 7 - LED DE STATUS ============ */
#define USAR_LED_STATUS  false
#define LED_PIN          2
#define LED_INVERTIDO    false

/* ============ FIM DA CONFIGURACAO ============ */

#define GEMINI_ENDPOINT "https://generativelanguage.googleapis.com/v1beta/models/" \
                        GEMINI_MODEL ":generateContent"

WiFiClientSecure client;
unsigned long ultimoAutomatico = 0;

void ledStatus(bool ligado) {
#if USAR_LED_STATUS
  digitalWrite(LED_PIN, LED_INVERTIDO ? !ligado : ligado);
#else
  (void)ligado;
#endif
}

void conectarWiFi() {
  Serial.println();
  Serial.print("[WiFi] Conectando em: ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long inicio = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    if (millis() - inicio > 20000) {
      Serial.println("\n[WiFi] Falhou. Reiniciando o ESP32...");
      ESP.restart();
    }
  }

  Serial.println("\n[WiFi] Conectado!");
  Serial.print("[WiFi] Endereco IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("[WiFi] Potencia do sinal (RSSI): ");
  Serial.print(WiFi.RSSI());
  Serial.println(" dBm");
}

String perguntarGemini(const String &pergunta) {

  JsonDocument doc;

  JsonArray contents = doc["contents"].to<JsonArray>();
  JsonObject turno   = contents.add<JsonObject>();
  turno["role"]      = "user";
  JsonArray parts    = turno["parts"].to<JsonArray>();
  parts.add<JsonObject>()["text"] = pergunta;

  JsonArray sysParts = doc["systemInstruction"]["parts"].to<JsonArray>();
  sysParts.add<JsonObject>()["text"] = SYSTEM_PROMPT;

  doc["generationConfig"]["temperature"]     = TEMPERATURE;
  doc["generationConfig"]["maxOutputTokens"] = MAX_TOKENS;

  String payload;
  serializeJson(doc, payload);

  client.setInsecure();

  HTTPClient https;
  if (!https.begin(client, GEMINI_ENDPOINT)) {
    return "[ERRO] Nao foi possivel iniciar a conexao HTTPS.";
  }

  https.addHeader("Content-Type", "application/json");
  https.addHeader("x-goog-api-key", GEMINI_API_KEY);
  https.setTimeout(20000);

  ledStatus(true);
  unsigned long t0 = millis();
  int codigoHTTP   = https.POST(payload);
  unsigned long latencia = millis() - t0;
  ledStatus(false);

  Serial.print("[HTTP] Codigo: ");
  Serial.print(codigoHTTP);
  Serial.print("  |  Latencia: ");
  Serial.print(latencia);
  Serial.println(" ms");

  if (codigoHTTP != HTTP_CODE_OK) {
    String erro = https.getString();
    https.end();
    return "[ERRO HTTP " + String(codigoHTTP) + "] " + erro;
  }

  String respostaBruta = https.getString();
  https.end();

#if DEBUG_JSON_BRUTO
  Serial.println("[DEBUG] JSON bruto recebido:");
  Serial.println(respostaBruta);
#endif

  JsonDocument filtro;
  filtro["candidates"][0]["content"]["parts"][0]["text"] = true;
#if DEBUG_FINISH_REASON
  filtro["candidates"][0]["finishReason"] = true;
#endif
#if DEBUG_CONTAGEM_TOKENS
  filtro["usageMetadata"] = true;
#endif

  JsonDocument resposta;
  DeserializationError erro = deserializeJson(
      resposta, respostaBruta, DeserializationOption::Filter(filtro));

  if (erro) {
    return String("[ERRO JSON] ") + erro.c_str();
  }

#if DEBUG_FINISH_REASON
  Serial.print("[DEBUG] finishReason: ");
  Serial.println((const char *)resposta["candidates"][0]["finishReason"]);
#endif

#if DEBUG_CONTAGEM_TOKENS
  Serial.print("[DEBUG] tokens entrada: ");
  Serial.print((int)resposta["usageMetadata"]["promptTokenCount"]);
  Serial.print("  |  tokens saida: ");
  Serial.print((int)resposta["usageMetadata"]["candidatesTokenCount"]);
  Serial.print("  |  total: ");
  Serial.println((int)resposta["usageMetadata"]["totalTokenCount"]);
#endif

  const char *texto = resposta["candidates"][0]["content"]["parts"][0]["text"];
  if (texto == nullptr) {
    return "[ERRO] Resposta sem texto (filtro de seguranca ou tokens esgotados).";
  }
  return String(texto);
}

void processarPergunta(const String &pergunta, const char *origem) {
  Serial.println("-------------------------------------------");
  Serial.print(origem);
  Serial.println(pergunta);
  Serial.println("[...] Consultando o Gemini, aguarde...");

  String resposta = perguntarGemini(pergunta);

  Serial.print("GEMINI: ");
  Serial.println(resposta);
  Serial.println("-------------------------------------------\n");
}

void setup() {
  Serial.begin(115200);
  delay(1000);

#if USAR_LED_STATUS
  pinMode(LED_PIN, OUTPUT);
  ledStatus(false);
#endif

  Serial.println("\n===========================================");
  Serial.println("   ESP32 + Gemini via API  -  FIAP Aula 03");
  Serial.println("===========================================");
  Serial.print("Modelo: ");
  Serial.println(GEMINI_MODEL);

  conectarWiFi();

  Serial.println("\nDigite sua pergunta e pressione ENTER.");
  Serial.println("(configure o Serial Monitor em 115200 e 'Nova linha')\n");
}

void loop() {

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WiFi] Conexao caiu. Reconectando...");
    conectarWiFi();
  }

#if MODO_AUTOMATICO
  if (millis() - ultimoAutomatico >= INTERVALO_AUTO_MS || ultimoAutomatico == 0) {
    ultimoAutomatico = millis();
    processarPergunta(PROMPT_AUTOMATICO, "AUTO: ");
  }
#endif

  if (Serial.available() > 0) {

    String pergunta = Serial.readStringUntil('\n');
    pergunta.trim();

    if (pergunta.length() == 0) return;

    processarPergunta(pergunta, "VOCE: ");
  }

  delay(50);
}
