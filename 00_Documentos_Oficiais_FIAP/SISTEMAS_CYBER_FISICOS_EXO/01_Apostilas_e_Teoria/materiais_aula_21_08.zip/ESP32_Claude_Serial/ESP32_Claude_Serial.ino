#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

#define WIFI_SSID         "COLOQUE_O_NOME_DA_SUA_REDE"
#define WIFI_PASSWORD     "COLOQUE_A_SENHA_DA_SUA_REDE"
#define ANTHROPIC_API_KEY "sk-ant-COLOQUE_SUA_CHAVE_AQUI"

#define CLAUDE_MODEL   "claude-haiku-4-5"
#define MAX_TOKENS     200
#define TEMPERATURE    0.7

#define CLAUDE_ENDPOINT   "https://api.anthropic.com/v1/messages"
#define ANTHROPIC_VERSION "2023-06-01"

#define SYSTEM_PROMPT "Voce e um assistente embarcado rodando em um ESP32. \
Responda sempre em portugues do Brasil, de forma curta e direta."

WiFiClientSecure client;

void conectarWiFi() {
  Serial.println();
  Serial.print("[WiFi] Conectando em: ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long inicio = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    if (millis() - inicio > 20000) {
      Serial.println("\n[WiFi] Falhou. Reiniciando o ESP32...");
      ESP.restart();
    }
  }

  Serial.println("\n[WiFi] Conectado!");
  Serial.print("[WiFi] Endereco IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("[WiFi] Potencia do sinal (RSSI): ");
  Serial.print(WiFi.RSSI());
  Serial.println(" dBm");
}

String perguntarClaude(const String &pergunta) {

  JsonDocument doc;
  doc["model"]       = CLAUDE_MODEL;
  doc["max_tokens"]  = MAX_TOKENS;
  doc["temperature"] = TEMPERATURE;
  doc["system"]      = SYSTEM_PROMPT;

  JsonArray messages = doc["messages"].to<JsonArray>();
  JsonObject usuario = messages.add<JsonObject>();
  usuario["role"]    = "user";
  usuario["content"] = pergunta;

  String payload;
  serializeJson(doc, payload);

  client.setInsecure();

  HTTPClient https;
  if (!https.begin(client, CLAUDE_ENDPOINT)) {
    return "[ERRO] Nao foi possivel iniciar a conexao HTTPS.";
  }

  https.addHeader("Content-Type", "application/json");
  https.addHeader("x-api-key", ANTHROPIC_API_KEY);
  https.addHeader("anthropic-version", ANTHROPIC_VERSION);
  https.setTimeout(20000);

  unsigned long t0 = millis();
  int codigoHTTP   = https.POST(payload);
  unsigned long latencia = millis() - t0;

  Serial.print("[HTTP] Codigo: ");
  Serial.print(codigoHTTP);
  Serial.print("  |  Latencia: ");
  Serial.print(latencia);
  Serial.println(" ms");

  if (codigoHTTP != HTTP_CODE_OK) {
    String erro = https.getString();
    https.end();
    return "[ERRO HTTP " + String(codigoHTTP) + "] " + erro;
  }

  String respostaBruta = https.getString();
  https.end();

  JsonDocument filtro;
  filtro["content"][0]["text"] = true;

  JsonDocument resposta;
  DeserializationError erro = deserializeJson(
      resposta, respostaBruta, DeserializationOption::Filter(filtro));

  if (erro) {
    return String("[ERRO JSON] ") + erro.c_str();
  }

  const char *texto = resposta["content"][0]["text"];
  if (texto == nullptr) {
    return "[ERRO] A resposta veio sem conteudo.";
  }
  return String(texto);
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n===========================================");
  Serial.println("   ESP32 + Claude via API  -  FIAP Aula 03");
  Serial.println("===========================================");

  conectarWiFi();

  Serial.println("\nDigite sua pergunta e pressione ENTER.");
  Serial.println("(configure o Serial Monitor em 115200 e 'Nova linha')\n");
}

void loop() {

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WiFi] Conexao caiu. Reconectando...");
    conectarWiFi();
  }

  if (Serial.available() > 0) {

    String pergunta = Serial.readStringUntil('\n');
    pergunta.trim();

    if (pergunta.length() == 0) return;

    Serial.println("-------------------------------------------");
    Serial.print("VOCE: ");
    Serial.println(pergunta);
    Serial.println("[...] Consultando o Claude, aguarde...");

    String resposta = perguntarClaude(pergunta);

    Serial.print("CLAUDE: ");
    Serial.println(resposta);
    Serial.println("-------------------------------------------\n");
  }

  delay(50);
}
